#include<SDL/SDL.h>
#include<GL/gl.h>
#include<GL/glu.h>
const float aspect=2.181818182;
void Draw_line(float V1 [3],float V2 [3])
{
    glBegin(GL_LINES);
        glVertex3f(V1[0]/aspect, V1[1]/aspect, V1[2]);
        glVertex3f(V2[0]/aspect, V2[1]/aspect, V2[2]);
    glEnd();
}

void init()
{
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45,640.0/480.0,1.0,500.0);
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_DEPTH_TEST);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glColor3f(0.0,0.0,0.0);
    glLineWidth(3.0);
    float V1 [3] = {-6.0, 0.0,-5.0};
    float V2 [3] = {6.0, 0.0,-5.0};
    Draw_line(V1,V2);
    float V3 [3] = {0.0, 6.0,-5.0};
    float V4 [3] = {0.0, -6.0,-5.0};
    Draw_line(V3,V4);
    glColor3f( 1.0, 0.0, 0.0);
    float V5 [3] = {3.0, -6.0,-5.0};
    float V6 [3] = {3.0, 6.0,-5.0};
    Draw_line(V5,V6);
    glColor3f( 0.0, 1.0, 0.0);
    float V7 [3] = {-6.0, -1.0,-5.0};
    float V8 [3] = {6.0, -1.0,-5.0};
    Draw_line(V7,V8);

}


int main(int argc, char* args[])
{
    SDL_Init(SDL_INIT_EVERYTHING);

    SDL_SetVideoMode(640,480,32,SDL_SWSURFACE|SDL_OPENGL);

    int petla=1;
//    Uint32 start;
    SDL_Event zdarzenie;
    init();
    while (petla==1)
    {
//        start=SDL_GetTicks();
        while (SDL_PollEvent(&zdarzenie))
        {
            switch(zdarzenie.type)
            {
                case SDL_QUIT:
                petla=0;
                break;
            }
        }
        display();
        SDL_GL_SwapBuffers();
//        if (1000/30>(SDL_GetTicks()-start)) SDL_Delay(SDL_GetTicks()-start);
    }
    SDL_Quit();
    return 0;
}
